// DEPRECATED: Replaced by components/Dock.tsx
import React from 'react';
export const Sidebar = () => null;